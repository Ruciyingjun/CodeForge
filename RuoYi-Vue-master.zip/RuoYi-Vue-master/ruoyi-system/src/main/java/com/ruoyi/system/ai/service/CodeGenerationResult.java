package com.ruoyi.system.ai.service;

/**
 * 代码生成结果
 */
public class CodeGenerationResult {
    private String code;
    private String explanation;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }
}