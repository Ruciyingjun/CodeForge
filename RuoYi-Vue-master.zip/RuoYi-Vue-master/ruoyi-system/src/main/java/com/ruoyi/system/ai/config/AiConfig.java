package com.ruoyi.system.ai.config;

public class AiConfig {
    public static final String MODEL_NAME = "通义千问";
    public static final String MODEL_TYPE = "qwen-turbo";
    public static final String API_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions";
    public static final String API_KEY = "sk-48dffd39ed4041568e30c142dc9f1500";
}