export const AI_CONFIG = {
  MODEL_NAME: '通义千问',  // 与后端 AiConfig.MODEL_NAME 保持一致
  MODEL_TYPE: 'qwen-turbo'  // 与后端 AiConfig.MODEL_TYPE 保持一致
}